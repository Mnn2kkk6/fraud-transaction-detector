import os
from dotenv import load_dotenv

load_dotenv()

MODEL_PATH = os.getenv("MODEL_PATH", "models/saved/fraud_model.pkl")
DATA_PATH = os.getenv("DATA_PATH", "data/raw/creditcard.csv")
THRESHOLD = float(os.getenv("THRESHOLD", 0.5))
DEBUG = os.getenv("DEBUG", "True") == "True"

RANDOM_STATE = 42
TEST_SIZE = 0.2
