from pydantic import BaseModel, Field
from typing import Optional

class TransactionInput(BaseModel):
    Time: float = Field(..., example=0.0)
    V1: float = Field(..., example=-1.36)
    V2: float = Field(..., example=-0.07)
    V3: float = Field(..., example=2.53)
    V4: float = Field(..., example=1.38)
    V5: float = Field(..., example=-0.34)
    V6: float = Field(..., example=0.46)
    V7: float = Field(..., example=0.24)
    V8: float = Field(..., example=0.09)
    V9: float = Field(..., example=0.36)
    V10: float = Field(..., example=0.09)
    V11: float = Field(..., example=-0.55)
    V12: float = Field(..., example=-0.61)
    V13: float = Field(..., example=-0.99)
    V14: float = Field(..., example=-0.31)
    V15: float = Field(..., example=1.47)
    V16: float = Field(..., example=-0.47)
    V17: float = Field(..., example=0.21)
    V18: float = Field(..., example=0.02)
    V19: float = Field(..., example=0.40)
    V20: float = Field(..., example=0.25)
    V21: float = Field(..., example=-0.02)
    V22: float = Field(..., example=0.28)
    V23: float = Field(..., example=-0.11)
    V24: float = Field(..., example=0.07)
    V25: float = Field(..., example=0.13)
    V26: float = Field(..., example=-0.19)
    V27: float = Field(..., example=0.13)
    V28: float = Field(..., example=-0.02)
    Amount: float = Field(..., example=149.62)

class PredictionResult(BaseModel):
    is_fraud: bool
    fraud_probability: float
    risk_level: str          # LOW / MEDIUM / HIGH
    model_used: str
