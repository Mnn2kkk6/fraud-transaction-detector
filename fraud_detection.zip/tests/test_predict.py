"""
pytest tests/
"""
from src.api.schemas import TransactionInput, PredictionResult

SAMPLE = {
    "Time": 0, "Amount": 149.62,
    **{f"V{i}": 0.0 for i in range(1, 29)}
}

def test_schema_valid():
    t = TransactionInput(**SAMPLE)
    assert t.Amount == 149.62

def test_prediction_result_fields():
    r = PredictionResult(is_fraud=False, fraud_probability=0.1, risk_level="LOW", model_used="RF")
    assert r.risk_level == "LOW"
    assert not r.is_fraud
